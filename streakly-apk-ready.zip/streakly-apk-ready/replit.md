# Streakly — Habit Tracker

A full-stack habit tracking app with XP/level gamification, streaks, badges, analytics, calendar, leaderboard, and an ad-unlock gate system.

## Architecture

- **Frontend**: React + Vite + TailwindCSS + shadcn/ui (in `client/`)
- **Backend**: Express.js with Passport.js session auth (in `server/`)
- **Database**: Supabase (PostgreSQL) via Drizzle ORM
- **Mobile**: Capacitor configured for Android APK export

## Key Files

- `shared/schema.ts` — 9 Drizzle tables (users, habits, habitCompletions, habitDailyXp, dailyLogs, badges, userBadges, settings, streakRewards)
- `shared/routes.ts` — Shared API route definitions
- `server/auth.ts` — Passport local strategy with scrypt password hashing
- `server/storage.ts` — DatabaseStorage implementing IStorage
- `server/routes.ts` — All API routes + badge seeding
- `client/src/App.tsx` — AuthGuard, ThemeSync, AdMob init, all routes
- `client/src/lib/admob.ts` — Capacitor AdMob native integration
- `client/src/components/ad-unlock-gate.tsx` — Ad gate (native AdMob on APK, Google AdSense on web)
- `capacitor.config.ts` — Capacitor config (appId: com.streakly.app)

## Features

- Habit tracking with streaks and longest streak tracking
- XP system: 10 XP per completion, streak milestone bonuses (3/7/14/30/60/100 days)
- Level system based on XP
- Weekly XP leaderboard
- Badge system with 6 seeded badges
- Analytics, Calendar, Daily Planner, Badges pages locked behind ad gate
- Ad gate: native AdMob rewarded ads on APK, Google AdSense on web (5s timer)
- Dark mode, sound settings

## AdMob Config

- App ID: `ca-app-pub-6278223211027037~4332224410` (Android)
- Ad Unit ID: `ca-app-pub-6278223211027037/2927076150` (Rewarded)
- Web publisher: `ca-pub-6278223211027037` (AdSense fallback)

## Building the Android APK

The Android APK cannot be built on Replit (requires Android Studio). Steps to build locally:

1. Deploy this Replit app to get a public URL
2. Update `capacitor.config.ts` → set `server.url` to your deployed URL
3. Run `npm run build` to build the frontend
4. Run `npx cap add android` (first time only)
5. Run `npx cap sync` to sync web assets into the Android project
6. Open `android/` folder in Android Studio
7. Build → Generate Signed APK

## Environment Secrets

- `SUPABASE_DATABASE_URL` — Pooled connection (used by the app)
- `SUPABASE_DIRECT_URL` — Direct connection (used by drizzle-kit)
- `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`
- `SESSION_SECRET` — Express session secret

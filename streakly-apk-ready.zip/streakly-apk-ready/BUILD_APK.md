# Building the Streakly Android APK

## Prerequisites
- Node.js 20+
- Java 17 (JDK)
- Android Studio (for signing) or Android SDK command-line tools

---

## Option A — GitHub Actions (Recommended, easiest)

1. Push this project to a GitHub repository.
2. Go to **Settings → Secrets → Actions** and add:
   - `CAPACITOR_SERVER_URL` → your deployed backend URL (e.g. `https://streakly.yourdomain.com`)
     *(Leave this secret unset if you want a fully self-contained APK with bundled assets.)*
3. Go to **Actions** tab → **Build Android APK** → **Run workflow**.
4. Download the APK from the workflow artifacts when complete.

---

## Option B — Build locally

```bash
# 1. Install dependencies
npm install

# 2. Build the frontend
npm run build

# 3. Add Android platform (first time only)
npx cap add android

# 4. Sync web assets into the Android project
npx cap sync android

# 5. Open in Android Studio to build & sign
npx cap open android
```

In Android Studio: **Build → Generate Signed Bundle/APK → APK**

---

## Environment variables needed at runtime (server-side)

Set these on your deployed backend:

| Variable | Description |
|---|---|
| `SUPABASE_DATABASE_URL` | Supabase pooled connection string |
| `SUPABASE_DIRECT_URL` | Supabase direct connection (for drizzle-kit) |
| `SUPABASE_URL` | Supabase project URL |
| `SUPABASE_ANON_KEY` | Supabase anon key |
| `SUPABASE_SERVICE_ROLE_KEY` | Supabase service role key |
| `SESSION_SECRET` | Express session secret (any random string) |

---

## AdMob IDs (already configured)

- Android App ID: `ca-app-pub-6278223211027037~4332224410`
- Rewarded Ad Unit: `ca-app-pub-6278223211027037/2927076150`

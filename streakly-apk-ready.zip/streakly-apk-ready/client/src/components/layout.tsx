import { useLocation, Link } from "wouter";
import { Home, Calendar, BarChart2, Award, Settings, Trophy } from "lucide-react";
import logoPath from "@assets/IMG_20260319_065451_1774073657710.png";

const NAV_ITEMS = [
  { path: "/", icon: Home, label: "Home" },
  { path: "/leaderboard", icon: Trophy, label: "Ranks" },
  { path: "/analytics", icon: BarChart2, label: "Stats" },
  { path: "/badges", icon: Award, label: "Badges" },
  { path: "/calendar", icon: Calendar, label: "Calendar" },
  { path: "/settings", icon: Settings, label: "Settings" },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  return (
    <div className="min-h-screen bg-background flex">
      <aside className="hidden md:flex flex-col w-60 bg-sidebar border-r border-sidebar-border min-h-screen fixed left-0 top-0 z-30">
        <div className="p-5 pb-4 flex items-center gap-3 border-b border-sidebar-border">
          <div className="w-9 h-9 bg-primary rounded-xl flex items-center justify-center shadow-lg shadow-primary/30 shrink-0 overflow-hidden">
            <img src={logoPath} alt="Streakly" className="w-full h-full object-cover" />
          </div>
          <div>
            <span className="font-black text-lg text-sidebar-foreground tracking-tight">Streakly</span>
            <p className="text-[9px] font-bold uppercase tracking-widest text-primary/60">Habit Tracker</p>
          </div>
        </div>
        <nav className="flex-1 p-3 space-y-0.5">
          {NAV_ITEMS.map(({ path, icon: Icon, label }) => {
            const isActive = location === path;
            return (
              <Link key={path} href={path}>
                <div
                  data-testid={`nav-${label.toLowerCase()}`}
                  className={`flex items-center gap-3 px-4 py-2.5 rounded-xl font-semibold transition-all cursor-pointer hover-elevate ${
                    isActive
                      ? "bg-primary text-primary-foreground shadow-md shadow-primary/20"
                      : "text-sidebar-foreground hover:bg-sidebar-accent"
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="text-sm">{label}</span>
                </div>
              </Link>
            );
          })}
        </nav>
      </aside>

      <main className="flex-1 md:ml-60 min-h-screen pb-[72px] md:pb-0">
        {children}
      </main>

      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-background/95 backdrop-blur-xl border-t border-border">
        <div
          className="grid pb-safe"
          style={{ gridTemplateColumns: "repeat(6, 1fr)" }}
        >
          {NAV_ITEMS.map(({ path, icon: Icon, label }) => {
            const isActive = location === path;
            return (
              <Link key={path} href={path}>
                <div
                  data-testid={`mobile-nav-${label.toLowerCase()}`}
                  className="flex flex-col items-center justify-center py-2 gap-0.5 cursor-pointer"
                >
                  <div
                    className={`flex items-center justify-center w-8 h-8 rounded-xl transition-all ${
                      isActive ? "bg-primary" : ""
                    }`}
                  >
                    <Icon
                      className={`w-[18px] h-[18px] transition-colors ${
                        isActive ? "text-white" : "text-muted-foreground"
                      }`}
                    />
                  </div>
                  <span
                    className={`text-[9px] font-bold leading-none transition-colors ${
                      isActive ? "text-primary" : "text-muted-foreground/50"
                    }`}
                  >
                    {label}
                  </span>
                </div>
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}

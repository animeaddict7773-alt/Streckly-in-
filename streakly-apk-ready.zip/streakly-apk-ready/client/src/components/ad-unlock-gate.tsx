import { useState, useEffect, useRef } from "react";
import { useSettings, useUnlockFeature, type FeatureKey } from "@/hooks/use-settings";
import { PlayCircle, Lock, Sparkles, Loader2, CheckCircle2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { isNative, showRewardedAd } from "@/lib/admob";

declare global {
  interface Window {
    adsbygoogle: unknown[];
  }
}

const AD_UNIT_SLOT = "2927076150";
const AD_WATCH_SECONDS = 5;

function WebAd() {
  const adRef = useRef<HTMLInsElement>(null);
  const pushed = useRef(false);

  useEffect(() => {
    if (!pushed.current && adRef.current) {
      try {
        (window.adsbygoogle = window.adsbygoogle || []).push({});
        pushed.current = true;
      } catch (_) {}
    }
  }, []);

  return (
    <ins
      ref={adRef}
      className="adsbygoogle"
      style={{ display: "block", width: "100%", minHeight: "100px" }}
      data-ad-client="ca-pub-6278223211027037"
      data-ad-slot={AD_UNIT_SLOT}
      data-ad-format="auto"
      data-full-width-responsive="true"
    />
  );
}

interface AdUnlockGateProps {
  feature: FeatureKey;
  title: string;
  description: string;
  children: React.ReactNode;
}

export function AdUnlockGate({ feature, title, description, children }: AdUnlockGateProps) {
  const { data: settings, isLoading } = useSettings();
  const unlockMutation = useUnlockFeature();
  const [isWatching, setIsWatching] = useState(false);
  const [countdown, setCountdown] = useState(AD_WATCH_SECONDS);
  const [adComplete, setAdComplete] = useState(false);
  const [nativeLoading, setNativeLoading] = useState(false);

  useEffect(() => {
    if (!isWatching || isNative()) return;
    setCountdown(AD_WATCH_SECONDS);
    setAdComplete(false);

    const interval = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setAdComplete(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isWatching]);

  if (isLoading) {
    return (
      <div className="w-full h-full min-h-[50vh] flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary/50" />
      </div>
    );
  }

  const unlockDateString = settings?.[`${feature}UnlockedUntil`] as string | null | undefined;
  const isUnlocked = unlockDateString ? new Date(unlockDateString) > new Date() : false;

  const handleWatchAd = async () => {
    if (isNative()) {
      setNativeLoading(true);
      const rewarded = await showRewardedAd();
      setNativeLoading(false);
      if (rewarded) {
        unlockMutation.mutate(feature);
      }
    } else {
      setIsWatching(true);
    }
  };

  const handleClaimUnlock = () => {
    unlockMutation.mutate(feature, {
      onSuccess: () => {
        setIsWatching(false);
        setAdComplete(false);
      },
      onError: () => {
        setIsWatching(false);
        setAdComplete(false);
      },
    });
  };

  if (isUnlocked) {
    return <>{children}</>;
  }

  return (
    <div className="relative w-full min-h-[70vh] flex flex-col items-center justify-center p-6 overflow-hidden rounded-3xl">
      <div className="absolute inset-0 opacity-30 blur-xl pointer-events-none select-none overflow-hidden" aria-hidden="true">
        {children}
      </div>

      <AnimatePresence mode="wait">
        {isWatching && !isNative() ? (
          <motion.div
            key="watching"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.1 }}
            className="relative z-10 flex flex-col items-center max-w-sm w-full glass-panel p-6 rounded-3xl text-center shadow-2xl shadow-primary/20 gap-4"
          >
            <div className="flex items-center justify-between w-full">
              <p className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
                Advertisement
              </p>
              {!adComplete ? (
                <span className="text-sm font-bold bg-primary/10 text-primary px-3 py-1 rounded-full">
                  {countdown}s
                </span>
              ) : (
                <span className="text-sm font-bold bg-green-500/10 text-green-500 px-3 py-1 rounded-full flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Done
                </span>
              )}
            </div>

            <div className="w-full bg-secondary/50 rounded-2xl overflow-hidden min-h-[120px] flex items-center justify-center border border-border/50">
              <WebAd />
            </div>

            <div className="w-full h-1.5 bg-secondary rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-primary"
                initial={{ width: "0%" }}
                animate={{ width: "100%" }}
                transition={{ duration: AD_WATCH_SECONDS, ease: "linear" }}
              />
            </div>

            {adComplete ? (
              <button
                onClick={handleClaimUnlock}
                disabled={unlockMutation.isPending}
                data-testid={`button-claim-unlock-${feature}`}
                className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-green-500 to-emerald-500 text-white px-6 py-3.5 rounded-xl font-bold shadow-lg shadow-green-500/25 hover:shadow-xl hover:-translate-y-0.5 transition-all duration-200 disabled:opacity-60"
              >
                {unlockMutation.isPending ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <CheckCircle2 className="w-5 h-5" />
                )}
                Claim 24-Hour Unlock
              </button>
            ) : (
              <p className="text-xs text-muted-foreground/70">
                Watch the ad to unlock <span className="font-semibold text-foreground">{title}</span> for 24 hours
              </p>
            )}
          </motion.div>
        ) : (
          <motion.div
            key="locked"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="relative z-10 flex flex-col items-center max-w-md w-full glass-panel p-8 md:p-10 rounded-3xl text-center shadow-2xl border-white/40"
          >
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-secondary to-background border border-border flex items-center justify-center mb-6 shadow-inner relative">
              <Lock className="w-8 h-8 text-muted-foreground" />
              <div className="absolute -top-2 -right-2 bg-accent text-accent-foreground p-1.5 rounded-full shadow-lg">
                <Sparkles className="w-4 h-4" />
              </div>
            </div>

            <h2 className="text-3xl font-bold mb-3 tracking-tight">{title}</h2>
            <p className="text-muted-foreground mb-8 leading-relaxed">
              {description}. Watch a short ad to unlock this premium feature for the next 24 hours. No subscriptions, ever.
            </p>

            <button
              onClick={handleWatchAd}
              disabled={nativeLoading}
              data-testid={`button-watch-ad-${feature}`}
              className="group relative w-full flex items-center justify-center gap-3 bg-gradient-to-r from-primary to-primary/80 text-white px-6 py-4 rounded-xl font-bold shadow-lg shadow-primary/25 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 active:translate-y-0 disabled:opacity-60"
            >
              {nativeLoading ? (
                <Loader2 className="w-6 h-6 animate-spin" />
              ) : (
                <PlayCircle className="w-6 h-6 group-hover:scale-110 transition-transform" />
              )}
              {nativeLoading ? "Loading Ad..." : "Watch Ad to Unlock"}
            </button>
            <p className="text-xs text-muted-foreground/60 mt-4 uppercase tracking-wider font-semibold">
              Unlocks for 24 Hours
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

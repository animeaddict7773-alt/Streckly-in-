import { useState, useEffect } from "react";
import { type InsertHabit, type Habit } from "@shared/routes";
import { Check, X, Droplet, Zap, Sun, Moon, Coffee, Dumbbell, Book, Music, Heart, Flame } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Dialog, DialogContent, DialogOverlay, DialogTitle } from "@/components/ui/dialog";

const HABIT_COLORS = [
  { id: 'rose', hex: '#FDA4AF' },
  { id: 'peach', hex: '#FDBA74' },
  { id: 'mint', hex: '#86EFAC' },
  { id: 'sage', hex: '#A7F3D0' },
  { id: 'sky', hex: '#7DD3FC' },
  { id: 'lavender', hex: '#C4B5FD' },
  { id: 'lilac', hex: '#D8B4FE' },
  { id: 'sand', hex: '#FDE047' },
];

const ICONS = [
  { id: 'droplet', Icon: Droplet },
  { id: 'zap', Icon: Zap },
  { id: 'sun', Icon: Sun },
  { id: 'moon', Icon: Moon },
  { id: 'coffee', Icon: Coffee },
  { id: 'dumbbell', Icon: Dumbbell },
  { id: 'book', Icon: Book },
  { id: 'music', Icon: Music },
  { id: 'heart', Icon: Heart },
  { id: 'flame', Icon: Flame },
];

interface HabitFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (habit: InsertHabit) => void;
  initialData?: Habit;
  isPending: boolean;
}

export function HabitForm({ isOpen, onClose, onSubmit, initialData, isPending }: HabitFormProps) {
  const [name, setName] = useState("");
  const [color, setColor] = useState(HABIT_COLORS[0].hex);
  const [icon, setIcon] = useState(ICONS[0].id);

  useEffect(() => {
    if (isOpen) {
      if (initialData) {
        setName(initialData.name);
        setColor(initialData.color);
        setIcon(initialData.icon);
      } else {
        setName("");
        setColor(HABIT_COLORS[0].hex);
        setIcon(ICONS[0].id);
      }
    }
  }, [isOpen, initialData]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    onSubmit({ name, color, icon, order: initialData?.order ?? 0 });
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogOverlay className="bg-black/20 backdrop-blur-sm" />
      <DialogContent className="sm:max-w-md bg-background border-border shadow-2xl p-0 overflow-hidden rounded-[2rem]">
        <div className="p-6 pb-0 flex justify-between items-center">
          <DialogTitle className="text-2xl font-bold">
            {initialData ? "Edit Habit" : "New Habit"}
          </DialogTitle>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-secondary transition-colors">
            <X className="w-5 h-5 text-muted-foreground" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-8">
          <div className="space-y-3">
            <label className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Name</label>
            <input
              autoFocus
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Read for 20 mins"
              className="w-full px-5 py-4 rounded-2xl bg-secondary/50 border border-transparent focus:bg-background focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all outline-none text-lg font-medium placeholder:text-muted-foreground/50"
              maxLength={40}
              data-testid="input-habit-name"
            />
          </div>

          <div className="space-y-3">
            <label className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Color</label>
            <div className="flex flex-wrap gap-3">
              {HABIT_COLORS.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setColor(c.hex)}
                  className="w-10 h-10 rounded-full flex items-center justify-center transition-transform hover:scale-110 active:scale-95"
                  style={{ backgroundColor: c.hex }}
                  data-testid={`color-${c.id}`}
                >
                  {color === c.hex && <Check className="w-5 h-5 text-black/50" />}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            <label className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Icon</label>
            <div className="grid grid-cols-5 gap-3">
              {ICONS.map((i) => {
                const isSelected = icon === i.id;
                return (
                  <button
                    key={i.id}
                    type="button"
                    onClick={() => setIcon(i.id)}
                    data-testid={`icon-${i.id}`}
                    className={`aspect-square rounded-2xl flex items-center justify-center transition-all ${
                      isSelected
                        ? 'bg-foreground text-background shadow-lg scale-110'
                        : 'bg-secondary text-muted-foreground hover:bg-secondary/80 hover:text-foreground'
                    }`}
                  >
                    <i.Icon className="w-6 h-6" />
                  </button>
                );
              })}
            </div>
          </div>

          <div className="pt-4">
            <button
              type="submit"
              disabled={isPending || !name.trim()}
              data-testid="button-save-habit"
              className="w-full py-4 rounded-2xl bg-foreground text-background font-bold text-lg shadow-xl shadow-black/10 hover:shadow-2xl hover:-translate-y-0.5 transition-all disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
            >
              {isPending ? "Saving..." : "Save Habit"}
            </button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { format } from "date-fns";
import { Flame, Plus, Check, Pencil, Trash2, Trophy, Zap, Star, ChevronRight, ClipboardList } from "lucide-react";
import { Layout } from "@/components/layout";
import { HabitForm } from "@/components/habit-form";
import { useHabits, useCreateHabit, useUpdateHabit, useDeleteHabit } from "@/hooks/use-habits";
import { useCompletions, useToggleCompletion } from "@/hooks/use-completions";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { api } from "@shared/routes";
import type { Habit } from "@shared/routes";
import {
  Droplet, Zap as ZapIcon, Sun, Moon, Coffee, Dumbbell, Book, Music, Heart,
} from "lucide-react";

const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  droplet: Droplet,
  zap: ZapIcon,
  sun: Sun,
  moon: Moon,
  coffee: Coffee,
  dumbbell: Dumbbell,
  book: Book,
  music: Music,
  heart: Heart,
  flame: Flame,
};

const LEVELS = [
  { level: 1, name: "Beginner", minXp: 0, maxXp: 500 },
  { level: 2, name: "Intermediate", minXp: 500, maxXp: 1500 },
  { level: 3, name: "Pro", minXp: 1500, maxXp: 3500 },
  { level: 4, name: "Elite", minXp: 3500, maxXp: 7500 },
  { level: 5, name: "Legend", minXp: 7500, maxXp: Infinity },
];

function getLevelInfo(xp: number) {
  for (let i = LEVELS.length - 1; i >= 0; i--) {
    if (xp >= LEVELS[i].minXp) return LEVELS[i];
  }
  return LEVELS[0];
}

interface RewardPopup {
  type: "xp" | "milestone" | "levelup" | "badge";
  xp?: number;
  milestone?: number;
  level?: number;
  badgeName?: string;
}

function XpBar({ xp, level }: { xp: number; level: number }) {
  const levelInfo = getLevelInfo(xp);
  const nextLevel = LEVELS[level] || LEVELS[LEVELS.length - 1];
  const isMaxLevel = level >= 5;
  const progressXp = xp - levelInfo.minXp;
  const rangeXp = isMaxLevel ? 1 : (levelInfo.maxXp - levelInfo.minXp);
  const pct = isMaxLevel ? 100 : Math.min(100, Math.round((progressXp / rangeXp) * 100));

  return (
    <div className="glass-panel rounded-2xl p-4 mb-6" data-testid="xp-bar">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
            <Star className="w-4 h-4 text-primary" />
          </div>
          <div>
            <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Level {levelInfo.level}</p>
            <p className="font-black text-sm text-foreground">{levelInfo.name}</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-xs text-muted-foreground font-medium">
            {isMaxLevel ? "MAX" : `${xp} / ${levelInfo.maxXp} XP`}
          </p>
          {!isMaxLevel && nextLevel && (
            <p className="text-[10px] text-muted-foreground/60">{nextLevel.name} next</p>
          )}
        </div>
      </div>
      <div className="h-2.5 bg-secondary rounded-full overflow-hidden">
        <motion.div
          className="h-full bg-gradient-to-r from-primary to-accent rounded-full"
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        />
      </div>
      <p className="text-xs text-muted-foreground mt-1.5 text-right font-medium">{pct}%</p>
    </div>
  );
}

function RewardOverlay({ popup, onClose }: { popup: RewardPopup; onClose: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/40 backdrop-blur-sm"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.7, y: 40 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.8, y: 20, opacity: 0 }}
        transition={{ type: "spring", stiffness: 400, damping: 28 }}
        className="glass-panel rounded-3xl p-8 text-center max-w-xs w-full shadow-2xl shadow-primary/20"
        onClick={(e) => e.stopPropagation()}
      >
        {popup.type === "xp" && (
          <>
            <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Zap className="w-10 h-10 text-primary" />
            </div>
            <h3 className="text-2xl font-black mb-1">+{popup.xp} XP</h3>
            <p className="text-muted-foreground font-medium">Habit completed!</p>
          </>
        )}
        {popup.type === "milestone" && (
          <>
            <div className="w-20 h-20 bg-orange-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Flame className="w-10 h-10 text-orange-500" />
            </div>
            <h3 className="text-2xl font-black mb-1">{popup.milestone}-Day Streak!</h3>
            <p className="text-muted-foreground font-medium">+{popup.xp} bonus XP earned</p>
          </>
        )}
        {popup.type === "levelup" && (
          <>
            <div className="w-20 h-20 bg-yellow-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Trophy className="w-10 h-10 text-yellow-500" />
            </div>
            <h3 className="text-2xl font-black mb-1">Level Up!</h3>
            <p className="text-muted-foreground font-medium">
              You reached Level {popup.level} — {LEVELS[(popup.level ?? 1) - 1]?.name ?? "Legend"}!
            </p>
          </>
        )}
        {popup.type === "badge" && (
          <>
            <div className="w-20 h-20 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Star className="w-10 h-10 text-accent" />
            </div>
            <h3 className="text-2xl font-black mb-1">Badge Earned!</h3>
            <p className="text-muted-foreground font-medium">{popup.badgeName}</p>
          </>
        )}
        <button
          onClick={onClose}
          className="mt-6 w-full py-3 rounded-2xl bg-primary text-primary-foreground font-bold shadow-lg hover-elevate"
          data-testid="button-dismiss-reward"
        >
          Keep Going
        </button>
      </motion.div>
    </motion.div>
  );
}

function HabitCard({
  habit,
  isCompleted,
  onToggle,
  onEdit,
  onDelete,
  isToggling,
}: {
  habit: Habit;
  isCompleted: boolean;
  onToggle: () => void;
  onEdit: () => void;
  onDelete: () => void;
  isToggling: boolean;
}) {
  const Icon = ICON_MAP[habit.icon] || Flame;
  const streakWarning = habit.streak > 0 && !isCompleted;
  const [showActions, setShowActions] = useState(false);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`relative flex items-center gap-4 p-4 rounded-2xl border transition-all ${
        isCompleted
          ? "bg-primary/5 border-primary/20"
          : streakWarning
          ? "bg-orange-500/5 border-orange-500/20"
          : "bg-card border-border"
      }`}
      data-testid={`habit-card-${habit.id}`}
    >
      <button
        onClick={onToggle}
        disabled={isToggling}
        data-testid={`toggle-habit-${habit.id}`}
        className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 transition-all active:scale-90 ${
          isCompleted
            ? "shadow-lg"
            : "border-2"
        }`}
        style={{
          backgroundColor: isCompleted ? habit.color : "transparent",
          borderColor: habit.color,
        }}
      >
        {isCompleted ? (
          <Check className="w-6 h-6 text-white" />
        ) : (
          <Icon className="w-6 h-6" style={{ color: habit.color }} />
        )}
      </button>

      <div className="flex-1 min-w-0">
        <p className={`font-bold text-base truncate ${isCompleted ? "line-through text-muted-foreground" : "text-foreground"}`}>
          {habit.name}
        </p>
        <div className="flex items-center gap-3 mt-0.5">
          {habit.streak > 0 && (
            <div className={`flex items-center gap-1 ${streakWarning ? "text-orange-500" : "text-primary"}`}>
              <Flame className="w-3.5 h-3.5" />
              <span className="text-xs font-bold">{habit.streak} day streak</span>
            </div>
          )}
          {streakWarning && habit.streak > 0 && (
            <span className="text-[10px] font-bold text-orange-500/80 uppercase tracking-wide">at risk</span>
          )}
        </div>
      </div>

      <div className="flex items-center gap-1">
        <button
          onClick={() => setShowActions(!showActions)}
          className="p-2 rounded-xl text-muted-foreground hover:text-foreground transition-colors"
          data-testid={`habit-menu-${habit.id}`}
        >
          <ChevronRight className={`w-4 h-4 transition-transform ${showActions ? "rotate-90" : ""}`} />
        </button>
        <AnimatePresence>
          {showActions && (
            <motion.div
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              className="flex items-center gap-1"
            >
              <button
                onClick={onEdit}
                className="p-2 rounded-xl text-muted-foreground hover:text-primary transition-colors"
                data-testid={`edit-habit-${habit.id}`}
              >
                <Pencil className="w-4 h-4" />
              </button>
              <button
                onClick={onDelete}
                className="p-2 rounded-xl text-muted-foreground hover:text-destructive transition-colors"
                data-testid={`delete-habit-${habit.id}`}
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}

export default function HomePage() {
  const today = format(new Date(), "yyyy-MM-dd");
  const { data: habits = [] } = useHabits();
  const { data: completions = [] } = useCompletions();
  const { data: user } = useQuery({ queryKey: ["/api/me"], retry: false });
  const queryClient = useQueryClient();
  const toggleCompletion = useToggleCompletion();
  const createHabit = useCreateHabit();
  const updateHabit = useUpdateHabit();
  const deleteHabit = useDeleteHabit();
  const { toast } = useToast();

  const [formOpen, setFormOpen] = useState(false);
  const [editHabit, setEditHabit] = useState<Habit | undefined>();
  const [popup, setPopup] = useState<RewardPopup | null>(null);
  const [togglingId, setTogglingId] = useState<number | null>(null);

  const { data: todayLog } = useQuery<{ oneTimeTasks: Array<{ id: string; text: string; completed: boolean }> } | undefined>({
    queryKey: ["/api/daily-logs", today],
    queryFn: async () => {
      const res = await fetch(`/api/daily-logs/${today}`, { credentials: "include" });
      if (res.status === 404 || res.status === 204) return undefined;
      if (!res.ok) return undefined;
      const text = await res.text();
      return text ? JSON.parse(text) : undefined;
    },
  });

  const todayTasks = (todayLog?.oneTimeTasks ?? []) as Array<{ id: string; text: string; completed: boolean }>;

  const toggleTask = useMutation({
    mutationFn: async (taskId: string) => {
      const updated = todayTasks.map((t) =>
        t.id === taskId ? { ...t, completed: !t.completed } : t
      );
      return apiRequest("PUT", `/api/daily-logs/${today}`, { oneTimeTasks: updated });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/daily-logs", today] });
    },
  });

  const todayCompletionIds = new Set(
    (completions as any[]).filter((c: any) => c.date === today).map((c: any) => c.habitId)
  );

  const todayCompleted = (habits as Habit[]).filter((h) => todayCompletionIds.has(h.id)).length;
  const todayTotal = (habits as Habit[]).length;
  const completionPct = todayTotal > 0 ? Math.round((todayCompleted / todayTotal) * 100) : 0;

  const handleToggle = async (habit: Habit) => {
    setTogglingId(habit.id);
    try {
      const result = await toggleCompletion.mutateAsync({ habitId: habit.id, date: today });

      queryClient.invalidateQueries({ queryKey: ["/api/me"] });
      queryClient.invalidateQueries({ queryKey: [api.leaderboard.get.path] });

      if (result.completed) {
        if (result.streakMilestone) {
          setPopup({ type: "milestone", milestone: result.streakMilestone, xp: result.xpGained });
        } else if (result.newLevel) {
          setPopup({ type: "levelup", level: result.newLevel });
        } else if (result.newBadge) {
          setPopup({ type: "badge", badgeName: result.newBadge.name });
        } else if (result.xpGained > 0) {
          setPopup({ type: "xp", xp: result.xpGained });
          setTimeout(() => setPopup(null), 2000);
        }
      }
    } catch {
      toast({ variant: "destructive", title: "Error", description: "Failed to update habit" });
    } finally {
      setTogglingId(null);
    }
  };

  const handleCreate = async (data: any) => {
    await createHabit.mutateAsync(data);
    setFormOpen(false);
  };

  const handleUpdate = async (data: any) => {
    if (!editHabit) return;
    await updateHabit.mutateAsync({ id: editHabit.id, ...data });
    setEditHabit(undefined);
    setFormOpen(false);
  };

  const handleDelete = async (id: number) => {
    await deleteHabit.mutateAsync(id);
    toast({ title: "Habit deleted" });
  };

  const xp = (user as any)?.xp ?? 0;
  const level = (user as any)?.level ?? 1;

  return (
    <Layout>
      <div className="px-5 pt-8 pb-6 max-w-lg mx-auto">
        <header className="mb-5">
          <div className="flex items-center justify-between mb-1">
            <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
              {format(new Date(), "EEEE, MMMM d")}
            </p>
          </div>
          <div className="flex items-center justify-between gap-3">
            <div>
              <h1 className="text-3xl font-black text-foreground leading-tight">Today</h1>
              {(user as any)?.username && (
                <p className="text-muted-foreground font-medium text-sm mt-0.5">
                  Hey, <span className="text-primary font-bold">{(user as any).username}</span>
                </p>
              )}
            </div>
            <button
              onClick={() => { setEditHabit(undefined); setFormOpen(true); }}
              data-testid="button-add-habit"
              className="flex items-center gap-1.5 bg-primary text-primary-foreground px-4 py-2.5 rounded-2xl font-bold shadow-lg shadow-primary/25 hover-elevate shrink-0 text-sm"
            >
              <Plus className="w-4 h-4" />
              New Habit
            </button>
          </div>
        </header>

        <XpBar xp={xp} level={level} />

        {todayTotal > 0 && (
          <div className="glass-panel rounded-2xl p-4 mb-6" data-testid="daily-progress">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm font-bold text-foreground">Daily Progress</p>
              <p className="text-sm font-black text-primary">{todayCompleted}/{todayTotal}</p>
            </div>
            <div className="h-2 bg-secondary rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-primary to-accent rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${completionPct}%` }}
                transition={{ duration: 0.6, ease: "easeOut" }}
              />
            </div>
            {completionPct === 100 && (
              <p className="text-xs text-primary font-bold mt-1.5 text-center">All habits done today!</p>
            )}
          </div>
        )}

        {todayTasks.length > 0 && (
          <div className="glass-panel rounded-2xl p-4 mb-5" data-testid="today-tasks">
            <div className="flex items-center gap-2 mb-3">
              <ClipboardList className="w-4 h-4 text-primary shrink-0" />
              <p className="text-sm font-bold text-foreground">Today's Tasks</p>
              <span className="ml-auto text-xs text-muted-foreground font-medium">
                {todayTasks.filter(t => t.completed).length}/{todayTasks.length} done
              </span>
            </div>
            <div className="space-y-2">
              {todayTasks.map((task) => (
                <button
                  key={task.id}
                  onClick={() => toggleTask.mutate(task.id)}
                  data-testid={`task-toggle-${task.id}`}
                  className="w-full flex items-center gap-3 text-left"
                >
                  <div className={`w-5 h-5 rounded-md border-2 flex items-center justify-center shrink-0 transition-all ${
                    task.completed
                      ? "bg-primary border-primary"
                      : "border-border"
                  }`}>
                    {task.completed && <Check className="w-3 h-3 text-white" />}
                  </div>
                  <span className={`text-sm font-medium leading-tight ${
                    task.completed ? "line-through text-muted-foreground/50" : "text-foreground"
                  }`}>
                    {task.text}
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="space-y-3">
          {(habits as Habit[]).length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-16"
            >
              <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Flame className="w-8 h-8 text-primary/60" />
              </div>
              <h3 className="font-bold text-foreground mb-2">No habits yet</h3>
              <p className="text-muted-foreground text-sm mb-6">Start building your routine by adding your first habit.</p>
              <button
                onClick={() => { setEditHabit(undefined); setFormOpen(true); }}
                className="bg-primary text-primary-foreground px-6 py-3 rounded-2xl font-bold shadow-lg shadow-primary/25 hover-elevate"
                data-testid="button-first-habit"
              >
                Add First Habit
              </button>
            </motion.div>
          ) : (
            (habits as Habit[]).map((habit) => (
              <HabitCard
                key={habit.id}
                habit={habit}
                isCompleted={todayCompletionIds.has(habit.id)}
                onToggle={() => handleToggle(habit)}
                onEdit={() => { setEditHabit(habit); setFormOpen(true); }}
                onDelete={() => handleDelete(habit.id)}
                isToggling={togglingId === habit.id}
              />
            ))
          )}
        </div>
      </div>

      <HabitForm
        isOpen={formOpen}
        onClose={() => { setFormOpen(false); setEditHabit(undefined); }}
        onSubmit={editHabit ? handleUpdate : handleCreate}
        initialData={editHabit}
        isPending={createHabit.isPending || updateHabit.isPending}
      />

      <AnimatePresence>
        {popup && (
          <RewardOverlay popup={popup} onClose={() => setPopup(null)} />
        )}
      </AnimatePresence>
    </Layout>
  );
}

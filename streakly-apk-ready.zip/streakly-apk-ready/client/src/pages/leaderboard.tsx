import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Trophy, Crown, Zap, Users, Star } from "lucide-react";
import { Layout } from "@/components/layout";
import { api } from "@shared/routes";

const LEVELS = [
  { level: 1, name: "Beginner", minXp: 0 },
  { level: 2, name: "Intermediate", minXp: 500 },
  { level: 3, name: "Pro", minXp: 1500 },
  { level: 4, name: "Elite", minXp: 3500 },
  { level: 5, name: "Legend", minXp: 7500 },
];

function getLevelName(xp: number) {
  for (let i = LEVELS.length - 1; i >= 0; i--) {
    if (xp >= LEVELS[i].minXp) return LEVELS[i].name;
  }
  return "Beginner";
}

function RankBadge({ rank }: { rank: number }) {
  if (rank === 1) return <Crown className="w-4 h-4 text-yellow-500" />;
  if (rank === 2) return <Trophy className="w-4 h-4 text-slate-400" />;
  if (rank === 3) return <Trophy className="w-4 h-4 text-amber-600" />;
  return <span className="text-xs font-black text-muted-foreground">#{rank}</span>;
}

function shortenUsername(name: string) {
  if (name.includes("@")) {
    const local = name.split("@")[0];
    return local.length > 12 ? local.slice(0, 12) + "…" : local;
  }
  return name.length > 14 ? name.slice(0, 14) + "…" : name;
}

export default function LeaderboardPage() {
  const { data, isLoading } = useQuery<{
    leaderboard: Array<{
      rank: number;
      username: string;
      xp: number;
      xpWeekly: number;
      level: number;
      isCurrentUser: boolean;
    }>;
    currentUserRank: number;
    totalUsers: number;
    xpBehindNext: number;
  }>({
    queryKey: [api.leaderboard.get.path],
    queryFn: async () => {
      const res = await fetch(api.leaderboard.get.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch leaderboard");
      return res.json();
    },
    refetchInterval: 30000,
  });

  return (
    <Layout>
      <div className="px-4 pt-8 pb-6 max-w-lg mx-auto">
        <header className="mb-6">
          <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-1">Rankings</p>
          <h1 className="text-3xl font-black text-foreground">Leaderboard</h1>
          <p className="text-muted-foreground text-sm font-medium mt-1">See how you stack up globally</p>
        </header>

        {data && (
          <div className="grid grid-cols-2 gap-3 mb-5">
            <div className="glass-panel rounded-2xl p-4" data-testid="stat-your-rank">
              <p className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground mb-1">Your Rank</p>
              <p className="text-3xl font-black text-foreground">#{data.currentUserRank}</p>
              <p className="text-xs text-muted-foreground">of {data.totalUsers} users</p>
            </div>
            <div className="glass-panel rounded-2xl p-4" data-testid="stat-xp-behind">
              <p className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground mb-1">XP to Next</p>
              {data.xpBehindNext > 0 ? (
                <>
                  <p className="text-3xl font-black text-foreground">{data.xpBehindNext}</p>
                  <p className="text-xs text-muted-foreground">XP behind next</p>
                </>
              ) : (
                <>
                  <p className="text-3xl font-black text-primary">Top!</p>
                  <p className="text-xs text-muted-foreground">You're in the lead</p>
                </>
              )}
            </div>
          </div>
        )}

        <div className="glass-panel rounded-2xl overflow-hidden mb-4">
          <div className="px-4 py-3 border-b border-border/50 flex items-center gap-2">
            <Zap className="w-4 h-4 text-primary shrink-0" />
            <span className="font-bold text-sm uppercase tracking-wide text-foreground">All-Time XP</span>
          </div>

          {isLoading ? (
            <div className="space-y-px">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="px-4 py-3 flex items-center gap-3 animate-pulse">
                  <div className="w-5 h-4 bg-secondary rounded" />
                  <div className="w-9 h-9 rounded-full bg-secondary shrink-0" />
                  <div className="flex-1 space-y-1.5">
                    <div className="h-3 bg-secondary rounded w-20" />
                    <div className="h-2 bg-secondary rounded w-14" />
                  </div>
                  <div className="h-4 bg-secondary rounded w-12" />
                </div>
              ))}
            </div>
          ) : data?.leaderboard.length === 0 ? (
            <div className="px-4 py-10 text-center">
              <Users className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" />
              <p className="text-muted-foreground font-medium">No rankings yet</p>
              <p className="text-muted-foreground/60 text-sm">Complete habits to earn XP and appear here</p>
            </div>
          ) : (
            <div>
              {data?.leaderboard.map((entry, i) => (
                <motion.div
                  key={entry.username}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className={`px-4 py-3 flex items-center gap-2.5 border-b border-border/30 last:border-0 ${
                    entry.isCurrentUser ? "bg-primary/5" : ""
                  }`}
                  data-testid={`leaderboard-row-${entry.rank}`}
                >
                  <div className="w-5 flex justify-center shrink-0">
                    <RankBadge rank={entry.rank} />
                  </div>

                  <div
                    className="w-9 h-9 rounded-full flex items-center justify-center font-black text-sm shrink-0 text-white"
                    style={{
                      background: entry.rank === 1
                        ? "linear-gradient(135deg, #f59e0b, #d97706)"
                        : entry.rank === 2
                        ? "linear-gradient(135deg, #94a3b8, #64748b)"
                        : entry.rank === 3
                        ? "linear-gradient(135deg, #b45309, #92400e)"
                        : "linear-gradient(135deg, hsl(252 80% 56%), hsl(280 75% 62%))",
                    }}
                  >
                    {entry.username.charAt(0).toUpperCase()}
                  </div>

                  <div className="flex-1 min-w-0">
                    <p className={`font-bold text-sm leading-tight truncate ${entry.isCurrentUser ? "text-primary" : "text-foreground"}`}>
                      {shortenUsername(entry.username)}
                      {entry.isCurrentUser && (
                        <span className="text-[10px] font-bold text-primary/60 ml-1">you</span>
                      )}
                    </p>
                    <p className="text-xs text-muted-foreground">{getLevelName(entry.xp)}</p>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <Star className="w-3 h-3 text-primary" />
                    <span className="font-black text-sm text-foreground tabular-nums">{entry.xp.toLocaleString()}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>

        <p className="text-center text-xs text-muted-foreground/60">
          Rankings update as you complete habits
        </p>
      </div>
    </Layout>
  );
}

import { useMemo } from "react";
import { format, subDays, eachDayOfInterval } from "date-fns";
import { motion } from "framer-motion";
import { BarChart2, Flame, CheckCircle2, TrendingUp, Calendar } from "lucide-react";
import { Layout } from "@/components/layout";
import { AdUnlockGate } from "@/components/ad-unlock-gate";
import { useHabits } from "@/hooks/use-habits";
import { useCompletions } from "@/hooks/use-completions";
import type { Habit } from "@shared/routes";

function StatCard({ label, value, icon: Icon, sub }: {
  label: string;
  value: string | number;
  icon: React.ComponentType<{ className?: string }>;
  sub?: string;
}) {
  return (
    <div className="glass-panel rounded-2xl p-5">
      <div className="flex items-center gap-3 mb-3">
        <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center">
          <Icon className="w-5 h-5 text-primary" />
        </div>
        <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">{label}</p>
      </div>
      <p className="text-3xl font-black text-foreground">{value}</p>
      {sub && <p className="text-xs text-muted-foreground mt-1">{sub}</p>}
    </div>
  );
}

function HeatmapCell({ count, max }: { count: number; max: number }) {
  const intensity = max === 0 ? 0 : count / max;
  return (
    <div
      className="w-3 h-3 rounded-sm"
      style={{
        backgroundColor: count === 0
          ? "hsl(var(--secondary))"
          : `hsl(252 80% ${Math.round(70 - intensity * 35)}%)`,
        opacity: count === 0 ? 0.4 : 0.7 + intensity * 0.3,
      }}
      title={`${count} completions`}
    />
  );
}

function WeeklyBar({ day, completions, total }: { day: string; completions: number; total: number }) {
  const pct = total === 0 ? 0 : (completions / total) * 100;
  return (
    <div className="flex flex-col items-center gap-1.5">
      <span className="text-xs font-black text-muted-foreground">{completions}/{total}</span>
      <div className="h-24 w-8 bg-secondary rounded-xl overflow-hidden flex flex-col-reverse">
        <motion.div
          className="w-full bg-gradient-to-t from-primary to-accent rounded-xl"
          initial={{ height: 0 }}
          animate={{ height: `${pct}%` }}
          transition={{ duration: 0.5, ease: "easeOut" }}
        />
      </div>
      <span className="text-[10px] font-bold uppercase text-muted-foreground">{day}</span>
    </div>
  );
}

export default function AnalyticsPage() {
  const { data: habits = [] } = useHabits();
  const { data: completions = [] } = useCompletions();

  const stats = useMemo(() => {
    const habitsArr = habits as Habit[];
    const compsArr = completions as any[];

    const totalCompletions = compsArr.length;
    const bestStreak = habitsArr.reduce((m, h) => Math.max(m, h.longestStreak), 0);
    const currentBestStreak = habitsArr.reduce((m, h) => Math.max(m, h.streak), 0);

    const last7Days = eachDayOfInterval({ start: subDays(new Date(), 6), end: new Date() });
    const weeklyData = last7Days.map((day) => {
      const dateStr = format(day, "yyyy-MM-dd");
      const count = compsArr.filter((c) => c.date === dateStr).length;
      return { day: format(day, "EEE"), date: dateStr, count };
    });

    const last90Days = eachDayOfInterval({ start: subDays(new Date(), 89), end: new Date() });
    const heatmapData = last90Days.map((day) => {
      const dateStr = format(day, "yyyy-MM-dd");
      const count = compsArr.filter((c) => c.date === dateStr).length;
      return { date: dateStr, count };
    });
    const heatmapMax = Math.max(...heatmapData.map((d) => d.count), 1);

    const habitStats = habitsArr.map((h) => {
      const hComps = compsArr.filter((c) => c.habitId === h.id);
      return { ...h, totalCompletions: hComps.length };
    }).sort((a, b) => b.totalCompletions - a.totalCompletions);

    const completedToday = compsArr.filter((c) => c.date === format(new Date(), "yyyy-MM-dd")).length;

    return {
      totalCompletions,
      bestStreak,
      currentBestStreak,
      weeklyData,
      heatmapData,
      heatmapMax,
      habitStats,
      completedToday,
      totalHabits: habitsArr.length,
    };
  }, [habits, completions]);

  return (
    <Layout>
      <AdUnlockGate
        feature="analytics"
        title="Analytics Dashboard"
        description="See detailed insights about your habit streaks, completion rates, and progress over time"
      >
        <div className="px-5 pt-8 pb-6 max-w-2xl mx-auto">
          <header className="mb-8">
            <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-1">Insights</p>
            <h1 className="text-3xl font-black text-foreground">Analytics</h1>
            <p className="text-muted-foreground font-medium mt-1">Track your progress over time</p>
          </header>

          <div className="grid grid-cols-2 gap-3 mb-6">
            <StatCard label="Total Done" value={stats.totalCompletions} icon={CheckCircle2} sub="habit completions" />
            <StatCard label="Best Streak" value={`${stats.bestStreak}d`} icon={Flame} sub="all-time record" />
            <StatCard label="Active Streak" value={`${stats.currentBestStreak}d`} icon={TrendingUp} sub="current best" />
            <StatCard label="Today" value={`${stats.completedToday}/${stats.totalHabits}`} icon={Calendar} sub="habits completed" />
          </div>

          <div className="glass-panel rounded-2xl p-5 mb-5">
            <h2 className="font-bold text-foreground mb-5 flex items-center gap-2">
              <BarChart2 className="w-5 h-5 text-primary" />
              This Week
            </h2>
            {stats.weeklyData.every((d) => d.count === 0) ? (
              <p className="text-muted-foreground text-sm text-center py-4">No completions this week yet.</p>
            ) : (
              <div className="flex items-end justify-between gap-2" data-testid="weekly-chart">
                {stats.weeklyData.map((d) => (
                  <WeeklyBar key={d.date} day={d.day} completions={d.count} total={stats.totalHabits} />
                ))}
              </div>
            )}
          </div>

          <div className="glass-panel rounded-2xl p-5 mb-5">
            <h2 className="font-bold text-foreground mb-4">90-Day Activity</h2>
            <div className="flex flex-wrap gap-1" data-testid="heatmap">
              {stats.heatmapData.map((d) => (
                <HeatmapCell key={d.date} count={d.count} max={stats.heatmapMax} />
              ))}
            </div>
            <div className="flex items-center gap-2 mt-3 justify-end">
              <span className="text-[10px] text-muted-foreground">Less</span>
              {[0, 1, 2, 3, 4].map((v) => (
                <div
                  key={v}
                  className="w-3 h-3 rounded-sm"
                  style={{ backgroundColor: v === 0 ? "hsl(var(--secondary))" : `hsl(252 80% ${Math.round(70 - (v / 4) * 35)}%)`, opacity: v === 0 ? 0.4 : 0.7 + (v / 4) * 0.3 }}
                />
              ))}
              <span className="text-[10px] text-muted-foreground">More</span>
            </div>
          </div>

          {stats.habitStats.length > 0 && (
            <div className="glass-panel rounded-2xl p-5">
              <h2 className="font-bold text-foreground mb-4">Habit Breakdown</h2>
              <div className="space-y-3">
                {stats.habitStats.map((h) => {
                  const pct = stats.totalCompletions === 0 ? 0 : Math.round((h.totalCompletions / stats.totalCompletions) * 100);
                  return (
                    <div key={h.id} data-testid={`habit-stat-${h.id}`}>
                      <div className="flex items-center justify-between mb-1.5">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: h.color }} />
                          <span className="font-semibold text-sm text-foreground">{h.name}</span>
                        </div>
                        <div className="text-right">
                          <span className="text-sm font-black text-foreground">{h.totalCompletions}</span>
                          <span className="text-xs text-muted-foreground ml-1">done</span>
                        </div>
                      </div>
                      <div className="h-2 bg-secondary rounded-full overflow-hidden">
                        <motion.div
                          className="h-full rounded-full"
                          style={{ backgroundColor: h.color }}
                          initial={{ width: 0 }}
                          animate={{ width: `${pct}%` }}
                          transition={{ duration: 0.5 }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </AdUnlockGate>
    </Layout>
  );
}

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Moon, Sun, Bell, LogOut, ChevronRight, Shield } from "lucide-react";
import { Layout } from "@/components/layout";
import { useSettings } from "@/hooks/use-settings";
import { api } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

function Toggle({ enabled, onToggle, testId }: { enabled: boolean; onToggle: () => void; testId: string }) {
  return (
    <button
      onClick={onToggle}
      data-testid={testId}
      className={`relative w-12 h-6 rounded-full transition-colors duration-200 ${enabled ? "bg-primary" : "bg-secondary"}`}
    >
      <motion.div
        animate={{ x: enabled ? 24 : 2 }}
        transition={{ type: "spring", stiffness: 500, damping: 30 }}
        className="absolute top-1 w-4 h-4 bg-white rounded-full shadow-md"
      />
    </button>
  );
}

function SettingRow({ label, sub, icon: Icon, children }: {
  label: string;
  sub?: string;
  icon: React.ComponentType<{ className?: string }>;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-center gap-4 py-4 border-b border-border/50 last:border-0">
      <div className="w-9 h-9 rounded-xl bg-secondary flex items-center justify-center shrink-0">
        <Icon className="w-5 h-5 text-muted-foreground" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-semibold text-foreground">{label}</p>
        {sub && <p className="text-xs text-muted-foreground mt-0.5">{sub}</p>}
      </div>
      {children}
    </div>
  );
}

export default function SettingsPage() {
  const { data: settings, isLoading } = useSettings();
  const { data: user } = useQuery({ queryKey: ["/api/me"], retry: false });
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const updateSettings = useMutation({
    mutationFn: async (updates: { darkMode?: boolean; soundEnabled?: boolean }) => {
      const res = await fetch(api.settings.update.path, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to update settings");
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.setQueryData([api.settings.get.path], data);
      if (data.darkMode) {
        document.documentElement.classList.add("dark");
      } else {
        document.documentElement.classList.remove("dark");
      }
    },
    onError: () => {
      toast({ variant: "destructive", title: "Error", description: "Failed to save settings" });
    },
  });

  const logout = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/logout", { method: "POST", credentials: "include" });
      if (!res.ok) throw new Error("Logout failed");
    },
    onSuccess: () => {
      queryClient.setQueryData(["/api/me"], null);
      queryClient.clear();
      window.location.href = "/auth";
    },
  });

  const darkMode = settings?.darkMode ?? false;
  const soundEnabled = settings?.soundEnabled ?? true;

  return (
    <Layout>
      <div className="px-5 pt-8 pb-6 max-w-lg mx-auto">
        <header className="mb-8">
          <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-1">Preferences</p>
          <h1 className="text-3xl font-black text-foreground">Settings</h1>
        </header>

        {(user as any)?.username && (
          <div className="glass-panel rounded-2xl p-5 mb-6 flex items-center gap-4" data-testid="user-profile">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-black text-xl shadow-lg shadow-primary/25">
              {(user as any).username.charAt(0).toUpperCase()}
            </div>
            <div>
              <p className="font-black text-foreground text-lg">{(user as any).username}</p>
              {(user as any).email && (
                <p className="text-muted-foreground text-sm">{(user as any).email}</p>
              )}
            </div>
          </div>
        )}

        <div className="glass-panel rounded-2xl px-5 mb-5">
          <SettingRow
            label="Dark Mode"
            sub="Switch to dark theme"
            icon={darkMode ? Moon : Sun}
          >
            {isLoading ? (
              <div className="w-12 h-6 bg-secondary rounded-full animate-pulse" />
            ) : (
              <Toggle
                enabled={darkMode}
                onToggle={() => updateSettings.mutate({ darkMode: !darkMode })}
                testId="toggle-dark-mode"
              />
            )}
          </SettingRow>

          <SettingRow
            label="Sound Effects"
            sub="Play sounds on completion"
            icon={Bell}
          >
            {isLoading ? (
              <div className="w-12 h-6 bg-secondary rounded-full animate-pulse" />
            ) : (
              <Toggle
                enabled={soundEnabled}
                onToggle={() => updateSettings.mutate({ soundEnabled: !soundEnabled })}
                testId="toggle-sound"
              />
            )}
          </SettingRow>
        </div>

        <div className="glass-panel rounded-2xl px-5 mb-5">
          <div className="py-4 border-b border-border/50">
            <div className="flex items-center gap-3 mb-1">
              <Shield className="w-4 h-4 text-muted-foreground" />
              <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Ad-Supported Features</p>
            </div>
            <p className="text-sm text-muted-foreground ml-7">
              Calendar, Analytics, Badges, and Daily Planner are unlocked for 24 hours by watching an ad. No subscriptions.
            </p>
          </div>
          <div className="py-3 text-xs text-muted-foreground/60 text-center">
            Streakly v2.0 · Built with care
          </div>
        </div>

        <button
          onClick={() => logout.mutate()}
          disabled={logout.isPending}
          data-testid="button-logout"
          className="w-full flex items-center justify-between gap-3 px-5 py-4 glass-panel rounded-2xl text-destructive font-bold hover-elevate transition-all"
        >
          <div className="flex items-center gap-3">
            <LogOut className="w-5 h-5" />
            <span>{logout.isPending ? "Signing out..." : "Sign Out"}</span>
          </div>
          <ChevronRight className="w-5 h-5 opacity-50" />
        </button>
      </div>
    </Layout>
  );
}

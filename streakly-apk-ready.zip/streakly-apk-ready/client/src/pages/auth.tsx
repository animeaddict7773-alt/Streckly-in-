import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation, useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { queryClient } from "@/lib/queryClient";
import { motion } from "framer-motion";
import { User, Lock, ArrowRight, Mail } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import logoPath from "@assets/IMG_20260319_065451_1774073657710.png";

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const { data: user } = useQuery({ queryKey: ['/api/me'], retry: false });
  if (user) {
    setLocation('/');
    return null;
  }

  const authMutation = useMutation({
    mutationFn: async (data: any) => {
      const path = isLogin ? api.auth.login.path : api.auth.register.path;
      const payload = isLogin ? { username: data.username, password: data.password } : data;
      const res = await fetch(path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        credentials: "include",
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Authentication failed");
      }
      return res.json();
    },
    onSuccess: (user) => {
      queryClient.setQueryData(["/api/me"], user);
      setLocation("/");
      toast({
        title: isLogin ? "Welcome back!" : "Account created!",
        description: `Successfully signed in as ${user.username}`,
      });
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message,
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    authMutation.mutate({ username, password, email });
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4 bg-gradient-to-br from-primary/5 via-background to-accent/5">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-sm glass-panel p-7 rounded-[2.5rem] shadow-2xl border-white/40"
      >
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-primary rounded-[1.25rem] flex items-center justify-center mx-auto mb-5 shadow-2xl shadow-primary/40 overflow-hidden">
            <img src={logoPath} alt="Streakly" className="w-full h-full object-cover" />
          </div>
          <h1 className="text-3xl font-black mb-0.5">{isLogin ? "Welcome Back" : "Join Streakly"}</h1>
          <p className="text-[11px] font-black uppercase tracking-widest text-primary/70 mb-2">Habit Tracker</p>
          <p className="text-muted-foreground font-medium text-sm">
            {isLogin ? "Continue your journey to greatness" : "Start building better habits today"}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Username</label>
            <div className="relative">
              <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full pl-10 pr-4 py-3.5 rounded-2xl bg-secondary/50 border-transparent focus:bg-background focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all outline-none font-medium border text-sm"
                placeholder="Enter your username"
                data-testid="input-username"
                autoComplete="username"
                required
              />
            </div>
          </div>

          {!isLogin && (
            <div className="space-y-1.5">
              <label className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Email</label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-3.5 rounded-2xl bg-secondary/50 border-transparent focus:bg-background focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all outline-none font-medium border text-sm"
                  placeholder="you@example.com"
                  data-testid="input-email"
                  autoComplete="email"
                />
              </div>
            </div>
          )}

          <div className="space-y-1.5">
            <label className="text-xs font-black uppercase tracking-widest text-muted-foreground ml-1">Password</label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-4 py-3.5 rounded-2xl bg-secondary/50 border-transparent focus:bg-background focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all outline-none font-medium border text-sm"
                placeholder="••••••••"
                data-testid="input-password"
                autoComplete={isLogin ? "current-password" : "new-password"}
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={authMutation.isPending}
            data-testid="button-auth-submit"
            className="w-full py-4 mt-2 rounded-2xl bg-primary text-white font-bold text-base shadow-xl shadow-primary/30 hover-elevate flex items-center justify-center gap-2 group disabled:opacity-50"
          >
            {authMutation.isPending ? "Authenticating..." : isLogin ? "Sign In" : "Create Account"}
            <ArrowRight className="w-5 h-5 group-hover:translate-x-0.5 transition-transform" />
          </button>
        </form>

        <div className="mt-6 text-center">
          <button
            onClick={() => setIsLogin(!isLogin)}
            className="text-primary font-bold text-sm hover:underline"
            data-testid="button-toggle-auth"
          >
            {isLogin ? "Don't have an account? Sign up" : "Already have an account? Sign in"}
          </button>
        </div>
      </motion.div>
    </div>
  );
}

import { useState, useEffect } from "react";
import { Layout } from "@/components/layout";
import { AdUnlockGate } from "@/components/ad-unlock-gate";
import { useHabits } from "@/hooks/use-habits";
import { useCompletions } from "@/hooks/use-completions";
import { DayPicker } from "react-day-picker";
import { format } from "date-fns";
import { Dialog, DialogContent, DialogOverlay, DialogTitle } from "@/components/ui/dialog";
import { useDailyLog, useUpdateDailyLog, useAllDailyLogs } from "@/hooks/use-daily-logs";
import { X, CheckCircle2, Circle, ListTodo, FileText, Plus, Trash2 } from "lucide-react";
import "react-day-picker/dist/style.css";

function DailyPlannerSheet({ date, isOpen, onClose }: { date: Date | null, isOpen: boolean, onClose: () => void }) {
  const dateStr = date ? format(date, 'yyyy-MM-dd') : '';
  const { data: dailyLog } = useDailyLog(dateStr);
  const { data: habits } = useHabits();
  const { data: completions } = useCompletions();
  const updateLog = useUpdateDailyLog();

  const [newTask, setNewTask] = useState("");
  const [localNotes, setLocalNotes] = useState("");

  useEffect(() => {
    setLocalNotes((dailyLog as any)?.notes || "");
  }, [(dailyLog as any)?.notes, dateStr]);

  if (!date) return null;

  const dayCompletions = (completions as any[])?.filter((c: any) => c.date === dateStr) || [];
  const completedHabits = (habits as any[])?.filter((h: any) => dayCompletions.some((c: any) => c.habitId === h.id)) || [];
  const tasks = (dailyLog as any)?.oneTimeTasks || [];

  const handleToggleTask = (taskId: string) => {
    const updated = tasks.map((t: any) => t.id === taskId ? { ...t, completed: !t.completed } : t);
    updateLog.mutate({ date: dateStr, oneTimeTasks: updated });
  };

  const handleAddTask = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!newTask.trim()) return;
    const task = { id: Math.random().toString(36).substring(7), text: newTask.trim(), completed: false };
    updateLog.mutate({ date: dateStr, oneTimeTasks: [...tasks, task] });
    setNewTask("");
  };

  const handleQuickAdd = (text: string) => {
    const task = { id: Math.random().toString(36).substring(7), text: text.trim(), completed: false };
    updateLog.mutate({ date: dateStr, oneTimeTasks: [...tasks, task] });
  };

  const handleDeleteTask = (taskId: string) => {
    const updated = tasks.filter((t: any) => t.id !== taskId);
    updateLog.mutate({ date: dateStr, oneTimeTasks: updated });
  };

  const handleSaveNotes = () => {
    if (localNotes !== (dailyLog as any)?.notes) {
      updateLog.mutate({ date: dateStr, notes: localNotes });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogOverlay className="bg-background/80 backdrop-blur-md" />
      <DialogContent className="sm:max-w-xl h-[85vh] sm:h-[80vh] flex flex-col bg-background border-border shadow-2xl p-0 overflow-hidden rounded-[2rem]">
        <div className="p-6 pb-4 border-b border-border/50 flex justify-between items-center bg-secondary/20">
          <div>
            <DialogTitle className="text-2xl font-bold text-foreground">
              {format(date, 'EEEE')}
            </DialogTitle>
            <p className="text-muted-foreground font-medium">{format(date, 'MMMM do, yyyy')}</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-secondary transition-colors">
            <X className="w-6 h-6 text-muted-foreground" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-8">
          <section>
            <div className="flex items-center gap-2 mb-4 text-primary font-bold tracking-wide uppercase text-sm">
              <CheckCircle2 className="w-5 h-5" /> Completed Habits
            </div>
            {completedHabits.length > 0 ? (
              <div className="flex flex-wrap gap-2">
                {completedHabits.map((h: any) => (
                  <div key={h.id} className="px-3 py-1.5 rounded-lg border flex items-center gap-2 text-sm font-medium shadow-sm" style={{ borderColor: h.color, backgroundColor: `${h.color}15`, color: h.color }}>
                    {h.name}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-sm italic">No habits completed on this day.</p>
            )}
          </section>

          <section>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2 text-primary font-bold tracking-wide uppercase text-sm">
                <ListTodo className="w-5 h-5" /> Schedule Tasks
              </div>
              <div className="flex gap-1">
                {(habits as any[])?.slice(0, 3).map((h: any) => (
                  <button
                    key={h.id}
                    onClick={() => handleQuickAdd(`Habit: ${h.name}`)}
                    className="text-[10px] px-2 py-1 rounded-full border border-primary/20 hover:bg-primary/10 transition-colors"
                  >
                    + {h.name}
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-2 mb-4">
              {tasks.length === 0 && (
                <p className="text-muted-foreground text-sm italic">No tasks yet. Add one below.</p>
              )}
              {tasks.map((task: any) => (
                <div key={task.id} className="flex items-center gap-3 group">
                  <button onClick={() => handleToggleTask(task.id)} className="shrink-0 text-muted-foreground hover:text-primary transition-colors" data-testid={`toggle-task-${task.id}`}>
                    {task.completed ? <CheckCircle2 className="w-6 h-6 text-primary" /> : <Circle className="w-6 h-6" />}
                  </button>
                  <span className={`flex-1 text-base transition-all ${task.completed ? 'line-through text-muted-foreground' : 'text-foreground font-medium'}`}>
                    {task.text}
                  </span>
                  <button onClick={() => handleDeleteTask(task.id)} className="shrink-0 opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive transition-all" data-testid={`delete-task-${task.id}`}>
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
            <form onSubmit={handleAddTask} className="flex gap-2">
              <input
                type="text"
                value={newTask}
                onChange={(e) => setNewTask(e.target.value)}
                placeholder="Add a task for this day..."
                className="flex-1 px-4 py-2.5 rounded-xl bg-secondary/50 border-transparent focus:bg-background focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all border"
                data-testid="input-new-task"
              />
              <button
                type="submit"
                disabled={!newTask.trim()}
                className="px-4 py-2.5 rounded-xl bg-primary text-primary-foreground font-bold hover:bg-primary/90 disabled:opacity-40 transition-colors flex items-center gap-1"
                data-testid="button-add-task"
              >
                <Plus className="w-5 h-5" />
              </button>
            </form>
          </section>

          <section className="flex-1 flex flex-col">
            <div className="flex items-center gap-2 mb-4 text-primary font-bold tracking-wide uppercase text-sm">
              <FileText className="w-5 h-5" /> Notes & Journal
            </div>
            <textarea
              value={localNotes}
              onChange={(e) => setLocalNotes(e.target.value)}
              onBlur={handleSaveNotes}
              placeholder="How did today go? Write your thoughts here..."
              className="w-full min-h-[150px] p-4 rounded-2xl bg-secondary/30 border border-border/50 focus:bg-background focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none resize-none transition-all text-base leading-relaxed"
            />
          </section>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function CalendarPage() {
  const { data: habits } = useHabits();
  const { data: completions } = useCompletions();
  const { data: allDailyLogs } = useAllDailyLogs();

  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [plannerOpen, setPlannerOpen] = useState(false);

  const renderDay = (props: any) => {
    const { date, displayMonth } = props;
    if (date.getMonth() !== displayMonth.getMonth()) return <div {...props} />;

    const dateStr = format(date, 'yyyy-MM-dd');
    const dayComps = (completions as any[])?.filter((c: any) => c.date === dateStr) || [];
    const completedColors = dayComps.map((c: any) => {
      const h = (habits as any[])?.find((h: any) => h.id === c.habitId);
      return h?.color;
    }).filter(Boolean).slice(0, 3);

    const dayLog = (allDailyLogs as any[])?.find((l: any) => l.date === dateStr);
    const hasTasks = dayLog?.oneTimeTasks?.length > 0;

    return (
      <div
        className="w-full h-full flex flex-col items-center justify-center relative cursor-pointer hover:bg-secondary rounded-xl transition-colors m-1"
        onClick={() => { setSelectedDate(date); setPlannerOpen(true); }}
      >
        <span className="font-semibold text-lg">{date.getDate()}</span>
        <div className="flex gap-1 mt-1 h-1.5 items-center">
          {completedColors.map((color: string, i: number) => (
            <div key={i} className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: color }} />
          ))}
          {hasTasks && (
            <div className="w-1.5 h-1.5 rounded-full bg-primary/40" />
          )}
        </div>
      </div>
    );
  };

  return (
    <Layout>
      <AdUnlockGate
        feature="calendar"
        title="Calendar & Daily Planner"
        description="See your habit history month by month. Tap any day to open the Daily Planner for one-time tasks and journaling"
      >
        <div className="p-6 md:p-10 pt-8 max-w-4xl mx-auto flex flex-col items-center">
          <header className="w-full mb-10 text-center md:text-left">
            <h1 className="text-3xl md:text-4xl font-bold tracking-tight">Calendar</h1>
            <p className="text-muted-foreground font-medium mt-2">Track your history over time.</p>
          </header>

          <div className="glass-panel p-4 md:p-8 rounded-[2.5rem] shadow-xl w-full max-w-md mx-auto inline-block border-white/40">
            <style>{`
              .rdp { margin: 0; --rdp-cell-size: 3rem; }
              .rdp-day_selected { background-color: hsl(var(--primary)); color: white; border-radius: 0.75rem; }
              .rdp-day_today { font-weight: 800; color: hsl(var(--primary)); }
              .rdp-head_cell { font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.05em; color: hsl(var(--muted-foreground)); }
            `}</style>
            <DayPicker
              mode="single"
              selected={selectedDate}
              onSelect={(date) => {
                if (date) { setSelectedDate(date); setPlannerOpen(true); }
              }}
              components={{ Day: renderDay as any }}
              className="w-full font-sans"
            />
          </div>

          <p className="text-muted-foreground text-sm mt-8 text-center bg-secondary/50 px-6 py-3 rounded-full inline-block">
            Tip: Tap any day to open the Daily Planner
          </p>
        </div>

        <DailyPlannerSheet
          date={selectedDate || null}
          isOpen={plannerOpen}
          onClose={() => setPlannerOpen(false)}
        />
      </AdUnlockGate>
    </Layout>
  );
}

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Trophy, Target, Flame, Zap, Shield, Star, Lock, X } from "lucide-react";
import { Layout } from "@/components/layout";
import { AdUnlockGate } from "@/components/ad-unlock-gate";
import { useBadges } from "@/hooks/use-badges";

const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  Target,
  Flame,
  Zap,
  Shield,
  Trophy,
  Star,
};

interface BadgeWithProgress {
  id: number;
  name: string;
  description: string;
  icon: string;
  type: string;
  target: number;
  xpReward: number;
  isEarned: boolean;
  progress: number;
}

function BadgeDetailModal({ badge, onClose }: { badge: BadgeWithProgress; onClose: () => void }) {
  const Icon = ICON_MAP[badge.icon] || Trophy;
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/50 backdrop-blur-sm"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.8, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="glass-panel rounded-3xl p-8 max-w-xs w-full text-center shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-end mb-2">
          <button onClick={onClose} className="p-1.5 rounded-full hover:bg-secondary transition-colors text-muted-foreground">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div
          className={`w-20 h-20 rounded-3xl mx-auto mb-5 flex items-center justify-center shadow-lg ${
            badge.isEarned ? "bg-primary/10 shadow-primary/20" : "bg-secondary"
          }`}
        >
          {badge.isEarned ? (
            <Icon className="w-10 h-10 text-primary" />
          ) : (
            <Lock className="w-10 h-10 text-muted-foreground" />
          )}
        </div>
        <h3 className="text-xl font-black text-foreground mb-2">{badge.name}</h3>
        <p className="text-muted-foreground text-sm mb-5">{badge.description}</p>
        <div className="space-y-3">
          <div className="flex justify-between items-center text-sm">
            <span className="text-muted-foreground font-medium">Progress</span>
            <span className="font-black text-foreground">{badge.progress}%</span>
          </div>
          <div className="h-2.5 bg-secondary rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-primary to-accent rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${badge.progress}%` }}
              transition={{ duration: 0.6, ease: "easeOut" }}
            />
          </div>
          <div className="flex items-center justify-center gap-1.5 bg-primary/5 rounded-xl py-2.5 px-4">
            <Zap className="w-4 h-4 text-primary" />
            <span className="font-black text-primary text-sm">+{badge.xpReward} XP reward</span>
          </div>
        </div>
        {badge.isEarned && (
          <div className="mt-4 text-xs font-bold text-primary/70 uppercase tracking-widest">Earned</div>
        )}
      </motion.div>
    </motion.div>
  );
}

function BadgeCard({ badge, onClick }: { badge: BadgeWithProgress; onClick: () => void }) {
  const Icon = ICON_MAP[badge.icon] || Trophy;
  return (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.97 }}
      onClick={onClick}
      data-testid={`badge-card-${badge.id}`}
      className={`glass-panel rounded-2xl p-5 text-center transition-all cursor-pointer w-full ${
        badge.isEarned ? "ring-2 ring-primary/30 shadow-primary/10" : "opacity-75"
      }`}
    >
      <div
        className={`w-14 h-14 rounded-2xl mx-auto mb-3 flex items-center justify-center shadow-md ${
          badge.isEarned ? "bg-primary/10" : "bg-secondary"
        }`}
      >
        {badge.isEarned ? (
          <Icon className="w-7 h-7 text-primary" />
        ) : (
          <div className="relative">
            <Icon className="w-7 h-7 text-muted-foreground/40" />
            <Lock className="w-3.5 h-3.5 text-muted-foreground absolute -bottom-1 -right-1 bg-background rounded-full" />
          </div>
        )}
      </div>
      <p className={`font-bold text-sm mb-1 ${badge.isEarned ? "text-foreground" : "text-muted-foreground"}`}>
        {badge.name}
      </p>
      {badge.isEarned ? (
        <span className="text-[10px] font-black uppercase tracking-widest text-primary">Earned</span>
      ) : (
        <div className="mt-2">
          <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
            <div
              className="h-full bg-primary/50 rounded-full"
              style={{ width: `${badge.progress}%` }}
            />
          </div>
          <p className="text-[10px] text-muted-foreground mt-1">{badge.progress}%</p>
        </div>
      )}
    </motion.button>
  );
}

export default function BadgesPage() {
  const { data: badges = [], isLoading } = useBadges();
  const [selectedBadge, setSelectedBadge] = useState<BadgeWithProgress | null>(null);

  const earned = (badges as BadgeWithProgress[]).filter((b) => b.isEarned);
  const locked = (badges as BadgeWithProgress[]).filter((b) => !b.isEarned);

  return (
    <Layout>
      <AdUnlockGate
        feature="badges"
        title="Achievements & Badges"
        description="Unlock achievements as you build streaks and complete habits"
      >
        <div className="px-5 pt-8 pb-6 max-w-2xl mx-auto">
          <header className="mb-8">
            <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-1">Achievements</p>
            <h1 className="text-3xl font-black text-foreground">Badges</h1>
            <p className="text-muted-foreground font-medium mt-1">
              {earned.length} of {(badges as BadgeWithProgress[]).length} earned
            </p>
          </header>

          {isLoading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="glass-panel rounded-2xl p-5 animate-pulse h-32" />
              ))}
            </div>
          ) : (
            <>
              {earned.length > 0 && (
                <div className="mb-6">
                  <h2 className="text-xs font-black uppercase tracking-widest text-primary mb-3">Earned</h2>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {earned.map((badge) => (
                      <BadgeCard key={badge.id} badge={badge} onClick={() => setSelectedBadge(badge)} />
                    ))}
                  </div>
                </div>
              )}

              {locked.length > 0 && (
                <div>
                  <h2 className="text-xs font-black uppercase tracking-widest text-muted-foreground mb-3">Locked</h2>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {locked.map((badge) => (
                      <BadgeCard key={badge.id} badge={badge} onClick={() => setSelectedBadge(badge)} />
                    ))}
                  </div>
                </div>
              )}

              {(badges as BadgeWithProgress[]).length === 0 && (
                <div className="text-center py-16">
                  <Trophy className="w-12 h-12 text-muted-foreground/40 mx-auto mb-4" />
                  <p className="text-muted-foreground font-medium">No badges yet</p>
                  <p className="text-muted-foreground/60 text-sm mt-1">Complete habits to unlock achievements</p>
                </div>
              )}
            </>
          )}
        </div>
      </AdUnlockGate>

      <AnimatePresence>
        {selectedBadge && (
          <BadgeDetailModal badge={selectedBadge} onClose={() => setSelectedBadge(null)} />
        )}
      </AnimatePresence>
    </Layout>
  );
}

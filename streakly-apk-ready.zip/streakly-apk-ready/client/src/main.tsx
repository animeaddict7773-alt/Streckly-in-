import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { removeReplitBadge } from "./lib/remove-replit-badge";

// Remove the Replit "Made in Replit" badge injected at runtime
removeReplitBadge();

createRoot(document.getElementById("root")!).render(<App />);

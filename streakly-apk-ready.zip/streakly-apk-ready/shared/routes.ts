import { z } from 'zod';
import { insertHabitSchema, habits, habitCompletions, dailyLogs, badges, settings, users, userBadges } from './schema';

export type Habit = typeof habits.$inferSelect;
export type InsertHabit = z.infer<typeof insertHabitSchema>;
export type HabitCompletion = typeof habitCompletions.$inferSelect;
export type DailyLog = typeof dailyLogs.$inferSelect;
export type Badge = typeof badges.$inferSelect;

export const errorSchemas = {
  validation: z.object({ message: z.string(), field: z.string().optional() }),
  notFound: z.object({ message: z.string() }),
  internal: z.object({ message: z.string() }),
};

export const api = {
  auth: {
    login: {
      method: 'POST' as const,
      path: '/api/login' as const,
      input: z.object({ username: z.string(), password: z.string() }),
      responses: { 200: z.custom<typeof users.$inferSelect>(), 401: errorSchemas.validation },
    },
    register: {
      method: 'POST' as const,
      path: '/api/register' as const,
      input: z.object({ username: z.string(), password: z.string() }),
      responses: { 201: z.custom<typeof users.$inferSelect>(), 400: errorSchemas.validation },
    },
    logout: {
      method: 'POST' as const,
      path: '/api/logout' as const,
      responses: { 200: z.object({ message: z.string() }) },
    },
    me: {
      method: 'GET' as const,
      path: '/api/me' as const,
      responses: { 200: z.custom<typeof users.$inferSelect>().nullable() },
    },
  },
  habits: {
    list: {
      method: 'GET' as const,
      path: '/api/habits' as const,
      responses: { 200: z.array(z.custom<typeof habits.$inferSelect>()) },
    },
    create: {
      method: 'POST' as const,
      path: '/api/habits' as const,
      input: insertHabitSchema,
      responses: { 201: z.custom<typeof habits.$inferSelect>(), 400: errorSchemas.validation },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/habits/:id' as const,
      input: insertHabitSchema.partial(),
      responses: { 200: z.custom<typeof habits.$inferSelect>(), 400: errorSchemas.validation, 404: errorSchemas.notFound },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/habits/:id' as const,
      responses: { 204: z.void(), 404: errorSchemas.notFound },
    },
  },
  completions: {
    list: {
      method: 'GET' as const,
      path: '/api/completions' as const,
      responses: { 200: z.array(z.custom<typeof habitCompletions.$inferSelect>()) },
    },
    toggle: {
      method: 'POST' as const,
      path: '/api/completions' as const,
      input: z.object({ habitId: z.number(), date: z.string() }),
      responses: {
        200: z.object({
          completed: z.boolean(),
          streak: z.number(),
          longestStreak: z.number(),
          xpGained: z.number(),
          newLevel: z.number().optional(),
          newBadge: z.custom<typeof badges.$inferSelect>().optional(),
          streakMilestone: z.number().optional(),
        }),
        400: errorSchemas.validation
      },
    },
  },
  dailyLogs: {
    get: {
      method: 'GET' as const,
      path: '/api/daily-logs/:date' as const,
      responses: { 200: z.custom<typeof dailyLogs.$inferSelect>().nullable() },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/daily-logs/:date' as const,
      input: z.object({ notes: z.string().optional(), oneTimeTasks: z.any().optional() }),
      responses: { 200: z.custom<typeof dailyLogs.$inferSelect>(), 400: errorSchemas.validation },
    },
  },
  badges: {
    list: {
      method: 'GET' as const,
      path: '/api/badges' as const,
      responses: { 200: z.array(z.custom<typeof badges.$inferSelect & { isEarned: boolean, progress: number }>()) },
    }
  },
  leaderboard: {
    get: {
      method: 'GET' as const,
      path: '/api/leaderboard' as const,
      responses: { 200: z.any() },
    },
  },
  settings: {
    get: {
      method: 'GET' as const,
      path: '/api/settings' as const,
      responses: { 200: z.custom<typeof settings.$inferSelect>() },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/settings' as const,
      input: z.object({ darkMode: z.boolean().optional(), soundEnabled: z.boolean().optional() }),
      responses: { 200: z.custom<typeof settings.$inferSelect>() },
    },
    unlockFeature: {
      method: 'POST' as const,
      path: '/api/settings/unlock' as const,
      input: z.object({ feature: z.enum(['analytics', 'calendar', 'dailyPlanner', 'badges', 'sharing', 'adsDisabled']) }),
      responses: { 200: z.custom<typeof settings.$inferSelect>(), 400: errorSchemas.validation },
    },
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
